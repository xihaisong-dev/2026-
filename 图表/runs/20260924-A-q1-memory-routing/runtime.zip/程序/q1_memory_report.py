"""Check bounded routing trials against frozen full100 rows, no ex-post oracle."""
import argparse, csv, json
from pathlib import Path
from statistics import mean
from q1_io import sha, write_json, verify


def load(p):return json.loads(p.read_text(encoding='utf8'))


def main():
    ap=argparse.ArgumentParser()
    for x in ['runs','baseline','diagnostics','output']:ap.add_argument('--'+x,type=Path,required=True)
    a=ap.parse_args();a.output.mkdir(parents=True,exist_ok=False);manifest=verify()
    old=load(a.baseline/'summary.json');base={(r['case'],r['cores']):r for r in old['runs']}
    results={};rows=[]
    for name in ['component_memory','component_hybrid']:
        root=a.runs/name;s=load(root/'summary.json')
        assert s['completed'] and not s['failures'] and len(s['runs'])==20
        assert s['config_sha256']==old['config_sha256']==manifest['files']['data/config.txt']
        for case,h in s['input_sha256'].items():assert h==old['input_sha256'][case]==manifest['files']['data/'+case]
        for f,h in s['code_sha256'].items():assert sha((root/'source_snapshot'/f).read_bytes())==h
        group=[]
        for r in s['runs']:
            b=base[r['case'],r['cores']];assert r['single_makespan']==b['single_makespan']
            folder=root/f"{r['case']}_{r['cores']}cores_seed0_{name}"
            for f,h in r['artifacts'].items():assert sha((folder/f).read_bytes())==h
            assert all(load(folder/'verification.json').values())
            st=load(folder/'search.json');assert len(st['evaluations'])==12 and st['official_calls']==11
            assert st['protected_grain_attempts']==[.5,1.,2.,.25]
            assert st['structural_seed_stats'].get('local_preparation',{}).get('global_evaluations',0)==0
            target=r['case'] not in ['case_028','case_067']
            if not target:
                assert load(folder/'plan.json')==load(a.baseline/f"{r['case']}_{r['cores']}cores_seed0_component_local_rank"/'plan.json')
            row=dict(config=name,case=r['case'],cores=r['cores'],target=target,before=b['makespan'],after=r['makespan'],
                     single=r['single_makespan'],before_bytes=b['added_copy_bytes'],after_bytes=r['added_copy_bytes'],
                     after_spill=r['spill_added_copy_bytes'],solve_seconds=r['solve_seconds'],validation_seconds=r['verification_seconds'],
                     structural_evaluations=r['structural_evaluations'],best_candidate=r['best_candidate'])
            group.append(row);rows.append(row)
        target=[r for r in group if r['target']]
        results[name]=dict(wins=sum(r['after']<r['before'] for r in target),ties=sum(r['after']==r['before'] for r in target),losses=sum(r['after']>r['before'] for r in target),
            time_reduction_pct=100*(1-sum(r['after'] for r in target)/sum(r['before'] for r in target)),
            bytes_reduction_pct=100*(1-sum(r['after_bytes'] for r in target)/sum(r['before_bytes'] for r in target)),
            per_core={k:dict(before=mean(r['single']/r['before'] for r in target if r['cores']==k),after=mean(r['single']/r['after'] for r in target if r['cores']==k)) for k in range(2,6)},protection_matches=8)
    diag=load(a.diagnostics/'summary.json');assert diag['completed'] and len(diag['rows'])==24
    result=dict(verified=True,scope='six targeted development graphs, two large protection graphs; not full100',variants=results,
                formal_runs=40,score_calls=440,reference_hits=40,final_official_replays=40,diagnostic_score_calls=sum(x['global_calls'] for x in diag['rows']))
    write_json(a.output/'summary.json',result)
    with (a.output/'comparison.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    lines=['# 内存路由与主导分量试验','',result['scope'],'','| 方案 | 目标12组胜/平/负 | 总时间下降 | 额外搬运下降 |','|---|---:|---:|---:|']
    for n,r in results.items():lines.append(f"| {n} | {r['wins']}/{r['ties']}/{r['losses']} | {r['time_reduction_pct']:.4f}% | {r['bytes_reduction_pct']:.4f}% |")
    lines+=['','每方案另外8组大图保护检查，028/067的2～5核方案与上一轮完全一致。每组12机会，四基础粒度保留；原版最终复核40份通过。诊断调用单列，离线最优候选不作为求解成绩。','',
        '并集内存量不是峰值，但真实溢出也不等于总体性能差；是否接受候选仍由官方Makespan主目标决定。主导分量仅拓扑连续有界切分，不穷举切点。','',
        '当前是定向开发验证，不能声称新的100图成绩。运行时间为并发服务器墙钟，原版复核单列，未承诺所有用例10分钟内完成。','',
        '| case | 核数 | 方案 | 原时间 | 新时间 | 新溢出bytes |','|---|---:|---|---:|---:|---:|']
    for r in sorted(rows,key=lambda r:(r['case'],r['cores'],r['config'])):
        if r['target']:lines.append(f"| {r['case']} | {r['cores']} | {r['config']} | {r['before']} | {r['after']} | {r['after_spill']} |")
    (a.output/'report.md').write_bytes(('\n'.join(lines)+'\n').encode());print(json.dumps(result,ensure_ascii=False))


if __name__=='__main__':main()
