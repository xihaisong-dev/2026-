"""Rebuild the development report from measured runs; never update official scores."""
import argparse,gzip,json
from pathlib import Path
from q1_io import ROOT,write_json

PREFIX='20260925-A-q1-timed-'
BATCHES=['smoke','pilot','cold','extension','large','deadline-test','large-bootstrap','large-seeded','large-fixed','large-final','holdout','final-smoke']

def load(p):return json.loads(p.read_text(encoding='utf-8'))
def evaluation(p):
    with gzip.open(p,'rt',encoding='utf-8') as f:return json.load(f)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
    a.output.mkdir(parents=True,exist_ok=False);records=[]
    for batch in BATCHES:
        folder=ROOT/'图表/runs'/(PREFIX+batch)
        if not (folder/'summary.json').exists():continue
        for row in load(folder/'summary.json')['runs']:
            row=dict(row,batch=batch);run_folder=folder/f"{row['case']}_{row['cores']}cores"
            old=ROOT/'图表/runs/20260924-A-q1-event-ranking-full100'/f"{row['case']}_{row['cores']}cores_seed0_routes_gate_reuse"
            run=load(run_folder/'run.json');row['worker_error']=run.get('worker_error',False)
            row['deadline_reached']=run.get('worker_deadline_reached',False)
            row['baseline_completed']=run.get('baseline_completed',False)
            row['valid_run']=row['complete'] and row['returncode']==0 and row['within_limit'] and not row['worker_error']
            row['source_hashes']=load(run_folder/'contract.json')['source_hashes']
            if row['complete']:
                result=evaluation(run_folder/run['selected']['folder']/'evaluation.json.gz')
                baseline=evaluation(old/'evaluation.json.gz')
                assert baseline['makespan']==row['before']
                assert result['makespan']==row['after']
                row['before_added_bytes']=baseline['data_movement_bytes']['added_copy_bytes']
                row['after_added_bytes']=result['data_movement_bytes']['added_copy_bytes']
            records.append(row)
    bybatch={}
    for batch in BATCHES:
        rows=[r for r in records if r['batch']==batch];ok=[r for r in rows if r['valid_run']]
        if not rows:continue
        bybatch[batch]=dict(count=len(rows),valid=len(ok),wins=sum(r['after']<r['before'] for r in ok),ties=sum(r['after']==r['before'] for r in ok),losses=sum(r['after']>r['before'] for r in ok))
    cold=[r for r in records if r['batch']=='cold' and r['valid_run']]
    points=[]
    for k in range(2,6):
        rows=[r for r in cold if r['cores']==k]
        points.append(dict(cores=k,count=len(rows),before_mean_speedup=sum(r['single']/r['before'] for r in rows)/len(rows),
            after_mean_speedup=sum(r['single']/r['after'] for r in rows)/len(rows),before_total_cycles=sum(r['before'] for r in rows),
            after_total_cycles=sum(r['after'] for r in rows),before_added_bytes=sum(r['before_added_bytes'] for r in rows),after_added_bytes=sum(r['after_added_bytes'] for r in rows)))
    write_json(a.output/'evidence.json',dict(role='development_only_not_full100',batches=bybatch,cold_five_case_points=points,records=records))
    lines=['# Q1 限时自适应算法组合：开发验证报告','',
        '目标：按图结构与真实收益调整启发式组合，在单个 case×核数配置的墙钟预算内降低官方 Makespan；相同时才比较额外搬运量。此报告不改写 100 图正式成绩。','',
        '## 实现与规则','',
        '1. 从计算图生成合法保底，再执行原有搜索。大图（超过4096个计算操作）以有界 Task 的保底代替重新生成整图单核基准；单核基准缺失时统计为 null，绝不用多核初解冒充单核基准。',
        '2. 工作量—活跃张量前沿切分：在合法拓扑序上按累计计算工作量定位窗口，结合活跃张量字节量选择边界；任务粒度可变，不组合枚举所有划分。',
        '3. 分量向量装箱：按各 Pipe 工作量分配完整弱连通分量，再以有限次数随机迁移改善最大负载，按不同批次形成 Task。共享输入亲和性仅用于候选启发，不计为跨 Task 私有缓存复用收益。',
        '4. 局部边界合并/拆分及关键路径、后续工作量感知的空隙插入调度。检查节点覆盖和缩点图无环；保留原版官方评估器判定的合法性与性能。',
        '5. 在上述候选生成器之间，根据已观察到的相对周期改善/耗时分配尝试，同时保留探索机会。方案规范化去重。不同 case 实际调用次数和组合不同，没有按 case 编号硬编码最优算法。',
        '6. 父进程监督墙钟截止，已接受方案采用原子指针落盘。原搜索阶段改善也逐次由原版官方重放后保存；被中断的新候选不参加择优。无已验证方案或异常会明确返回失败。','',
        '目标按 (Makespan, added_copy_bytes) 字典序排序。所有保存方案经过原版官方场景 A 评估，DDR 竞争、等待、缓存清空和核内调度均由官方程序计算。启发式预测并非最终成绩。','',
        '## 验证口径','',
        '- 原对照为冻结 routes_gate_reuse 全100图结果；其搜索预算为12次，本次允许更长墙钟时间和更多候选。因此收益属于“新组合＋新增计算预算”的合并效果，不能写为同12次预算算法提升。',
        '- cold 为从原始图生成方案，无历史 plan 作为输入。warm 明确读取旧 plan；二者分表。大图不重复生成单核计分基准，报告加速比使用既有官方固定整图单核结果。',
        '- 五图开发集为006、048、071、078、100；补测集为012、037、059、084，补测选定后没有按结果调整规则。它们都不是随机抽样全量结论。',
        '- 限时单位是单个 case×核数；不宣称同一图四个核数全部在十分钟内，也不将额外独立审计的耗时混入求解耗时。默认590秒留有退出余量；不保证任意硬件任意输入都能在期限前产生首个方案，run.json会显式标记。','',
        '## 批次完整结果','',
        '|批次|配置数|有效|改善|持平|退步|','|---|---:|---:|---:|---:|---:|']
    for batch,r in bybatch.items():lines.append(f"|{batch}|{r['count']}|{r['valid']}|{r['wins']}|{r['ties']}|{r['losses']}|")
    lines+=['','## 五图冷启动：官方定义的平均加速比','',
        '使用 mean(T1_i/Tk_i)，并列给出总周期；这是5图均值，不是100图新成绩。1核点固定为1。','',
        '|核数|旧平均加速比|新平均加速比|旧总周期|新总周期|额外搬运字节变化|','|---|---:|---:|---:|---:|---:|']
    for p in points:lines.append(f"|{p['cores']}|{p['before_mean_speedup']:.6f}|{p['after_mean_speedup']:.6f}|{p['before_total_cycles']}|{p['after_total_cycles']}|{p['after_added_bytes']-p['before_added_bytes']:+d}|")
    lines+=['','## 大图及已知失败','',
        '- case_072 60秒初版未保存首个方案；限制保底 Task 大小后取得合法结果，但180秒版本仍劣于旧结果。中间一次修复因空单核基准参与奖励归一化而异常，已修复并保留日志。',
        '- case_072 最终590秒试验保存结果但原搜索阶段未完成，仍略逊于旧方案。说明原有候选生成/评估会阻塞后续组合，硬截止仅保证及时返回，不能保证质量。当前不据此全局替换默认提交算法。',
        '- case_067 590秒冷启动试验改善；不同源码修订均在各次 contract.json 中保留哈希。此报告没有把跨版本事后最优伪装为单一冻结版本成绩。',
        '- 部分改进以增加额外搬运量换取较短周期。次目标不是同时必然改善；逐组字节值见 evidence.json。',
        '- 后续首要修正：为大图原搜索阶段设置可中断的独立份额，保护后续组合机会；冻结规则和源码后再做100图2～5核全量验证。当前只有本轮开发证据，正式全量门禁 NOT_RUN。','',
        '## 复现','',
        '先按仓库说明导入并验证官方附件。使用仓库 Python 环境，输出目录必须尚不存在。','',
        '```powershell',
        'python 程序/q1_timed_portfolio.py 数据/processed/q1/data/case_071.json -n 5 --seconds 590 --seed 0 --output 图表/runs/my-q1-071',
        'python 程序/q1_timed_campaign.py --cases 6 48 71 78 100 --cores 2 3 4 5 --seconds 90 --workers 4 --cold --output 图表/runs/my-q1-cold',
        'python 程序/q1_timed_verify.py --runs 图表/runs/my-q1-071 --output 图表/runs/my-q1-071-replay.json',
        '```','',
        '主入口 q1_submit.py 保持原默认方案。新入口 q1_timed_portfolio.py 输出官方格式 case_XXX_multicore_res.json；accepted_*/evaluation.json.gz 是完整官方结果，run.json 记录超时/异常/限时状态，contract.json 记录输入和源码哈希。',
        '固定种子保证候选生成可复现；墙钟截止下不同机器会评估不同数量的候选，不能承诺输出逐字节一致。保存方案的官方重放结果应一致。']
    (a.output/'README.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps(bybatch,ensure_ascii=False))

if __name__=='__main__':main()
