# Problem 1 submission data

100 cases x 1--5 cores. Makespan unit: cycles; movement unit: bytes. Mean speedup is mean(T1/Tn).
Cores 1--4: new unchanged Allin2 standard search, independently replayed.
Core 5: reconstructed historical delivered methods, exact score and traffic replay match. Reconstruction is not a fresh blind search or timing benchmark.
No formal stage approval, human acceptance, or contest upload is implied.
